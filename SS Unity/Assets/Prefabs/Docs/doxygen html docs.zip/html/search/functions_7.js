var searchData=
[
  ['isnewswapattempt',['IsNewSwapAttempt',['../a00035.html#a70aadcedbfa03dcc7cc42a86789940ab',1,'PowerGridInventory::PGIModel::SwapCache']]],
  ['israycastlocationvalid',['IsRaycastLocationValid',['../a00005.html#a73a27c298277deef81c2c0966b010f89',1,'PowerGridInventory::Utility::IgnoreUIRaycasts']]]
];
