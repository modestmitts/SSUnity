var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvxyz",
  1: "acdilpst",
  2: "ap",
  3: "acdefghimoprstu",
  4: "abcdeghimnoprstvxyz",
  5: "ir",
  6: "abeghimrsxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Properties"
};

