var searchData=
[
  ['batchslots',['BatchSlots',['../a00026.html#a471799de95cf4d04aa4e186497970585',1,'PowerGridInventory::PGIView']]],
  ['blocked',['Blocked',['../a00020.html#afff12f902260b362508c3567ca700964',1,'PowerGridInventory::PGISlot']]],
  ['blockedcolor',['BlockedColor',['../a00026.html#a9fa724848aa5bd28415f9e575e9665da',1,'PowerGridInventory::PGIView']]]
];
