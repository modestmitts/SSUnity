var searchData=
[
  ['gridcellsx',['GridCellsX',['../a00018.html#aa1ecb6f9fcae69596708b4d1f9f6cf31',1,'PowerGridInventory::PGIModel']]],
  ['gridcellsy',['GridCellsY',['../a00018.html#acd0d88649839eb3be1e9b3c55aa3e95d',1,'PowerGridInventory::PGIModel']]],
  ['griditems',['GridItems',['../a00018.html#a6bcd3b369dcea0d2629c09e850f02825',1,'PowerGridInventory::PGIModel']]]
];
