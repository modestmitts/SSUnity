var searchData=
[
  ['blocked',['Blocked',['../a00020.html#afff12f902260b362508c3567ca700964',1,'PowerGridInventory::PGISlot']]]
];
