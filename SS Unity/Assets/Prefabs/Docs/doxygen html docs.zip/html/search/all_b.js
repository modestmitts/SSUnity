var searchData=
[
  ['normalcolor',['NormalColor',['../a00026.html#a25f5b48b8613c0c4f3b050200dd04d48',1,'PowerGridInventory::PGIView']]]
];
